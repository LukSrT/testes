//////////////////////////////////////////////////////////////////////
// This file is part of Remere's Map Editor
//////////////////////////////////////////////////////////////////////
// $URL: https://rme.svn.sourceforge.net/svnroot/rme/trunk/source/common.h $
// $Id: common.h 264 2009-10-05 06:36:21Z remere $

#ifndef RME_JSON_H_
#define RME_JSON_H_

#include "json/json_spirit.h"

namespace json {
	using namespace json_spirit;
}

#endif

